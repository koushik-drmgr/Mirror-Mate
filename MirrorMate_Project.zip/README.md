# Mirror Mate – Find Your Doppelgänger  

**Mirror Mate** is a fun web platform where users can find their *digital doppelgänger* and connect through classic games like **Chess, Checkers, and Tic-Tac-Toe**.  

## 🚀 Features  
- 🌐 Clean landing page with navigation (Home, Games, About)  
- 🎮 Built-in games: Chess, Checkers, Tic-Tac-Toe  
- 📱 Responsive design  

## 🛠️ Tech Stack  
- HTML5, CSS3, JavaScript  
- Flask (Python) – optional backend  

## ▶️ How to Run  
### Option 1: Open in Browser  
Simply open `index.html`.  

### Option 2: Run with Flask  
```bash
pip install flask
python server.py
```
Then visit `http://127.0.0.1:5000/`  
